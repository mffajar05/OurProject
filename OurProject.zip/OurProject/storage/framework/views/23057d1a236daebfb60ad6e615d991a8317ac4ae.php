

<?php $__env->startSection('title','Kantinkita'); ?>

<?php $__env->startSection('content'); ?>
    




<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OurProject\resources\views/page/admin/konfirmasi.blade.php ENDPATH**/ ?>