<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>
<body>
     <!-- Begin Page Content -->
     <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Data Dosen Universitas Borneo </h1>
        <p class="mb-4"> Tahun Ajaran 2021-2022</p>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class=" btn btn-primary"><a href="<?php echo e(url('/dosens/tambah')); ?>"">Tambah Data</a></h6>

                <?php if(session('status')): ?>
                <div class="alert alert-succes">
                    <?php echo e(session('status')); ?>


                </div>

                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th scope="row"> No </th>
                                <th>NIDN</th>
                                <th>Nama Lengkap</th>
                                <th>Tempat Lahir</th>
                                <th>Tanggal Lahir</th>
                                <th>Jenis Kelamin</th>
                                <th>Alamat</th>
                                <th>Program Studi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dsn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scoop="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($dsn->nidn); ?></td>
                                <td><?php echo e($dsn->nama_lengkap); ?></td>
                                <td><?php echo e($dsn->tempat_lahir); ?></td>
                                <td><?php echo e($dsn->tanggal_lahir); ?></td>
                                <td><?php echo e($dsn->jenis_kelamin); ?></td>
                                <td><?php echo e($dsn->alamat); ?></td>
                                <td><?php echo e($dsn->program_studi); ?></td>
                                <td>
                                    <a href="/dosens/<?php echo e($dsn->id); ?>" class="badge badge-succes">Detail</a>
                            </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->


</body>
</html>
<?php /**PATH C:\xampp\htdocs\OurProject\resources\views/dosen.blade.php ENDPATH**/ ?>