<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>
<body>
    <h2>Form Ubah Data Dosen</h2>
   <form class=" col-7 heigh" method="post" action="/dosens">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="nama_lengkap">NAMA</label>
        <input type="text" class="form-control" placeholder="Masukan Nama" id="nama_lengkap" name="nama_lengkap" value="<?php echo e($dosen->nama_lengkap); ?>">
      </div>
      <div class="form-group">
        <label for="nidn">NIDN</label>
        <input type="text" class="form-control" placeholder="Nomor Induk Dosen Nasional" id="nidn" name="nidn" value="<?php echo e($dosen->nidn); ?>">
      </div>
      <div class="form-group">
        <label for="tempat_lahir">Tempat lahir</label>
        <input type="text" class="form-control" placeholder="Tempat Lahir" id="tempat_lahir" name="tempat_lahir" value="<?php echo e($dosen->tempat_lahir); ?>">
      </div>
      <div class="form-group">
        <label for="tanggal_lahir">Tanggal lahir</label>
        <input type="text" class="form-control" placeholder="yyyy-mm-dd" id="tanggal_lahir" name="tanggal_lahir" value="<?php echo e($dosen->tanggal_lahir); ?>">
      </div>
      <div class="form-group">
        <label for="jenis_kelamin">Jenis kelamin</label>
        <input type="text" class="form-control" placeholder="Jenis Kelamin" id="jenis_kelamin" name="jenis_kelamin" value="<?php echo e($dosen->jenis_kelamin); ?>">
      </div>
      <div class="form-group">
        <label for="alamat">Alamat</label>
        <input type="text" class="form-control" placeholder="Alamat" id="alamat" name="alamat" value="<?php echo e($dosen->alamat); ?>">
      </div>
      <div class="form-group">
        <label for="program_studi">Program Studi</label>
        <input type="text" class="form-control" placeholder="Program Studi" id="program_studi" name="program_studi" value="<?php echo e($dosen->program_studi); ?>">
      </div>
      <button type="submit" class="btn btn-primary">Ubah Data</button>
   </form>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\OurProject\resources\views/edit.blade.php ENDPATH**/ ?>