<?php $__env->startSection('title','Kantinkita'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Management Produk</h1>
                    <p class="mb-4"> Management Produk kantinKita.id</p>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th scope="row"> # </th>
                                            <th>Kode Produk</th>
                                            <th>Nama Produk</th>
                                            <th>Harga</th>
                                            <th>Kategori</th>
                                            <th>Deskripsi Produk</th>
                                            <th>Kadaluarsa</th>
                                            <th>Stok</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $mproduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scoop="row"><?php echo e($loop->iteration); ?></th>
                                            <td><?php echo e($mp-> kode_produk); ?></td>
                                            <td><?php echo e($mp-> nama_produk); ?></td>
                                            <td><?php echo e($mp-> harga); ?></td>
                                            <td><?php echo e($mp-> kategori); ?></td>
                                            <td><?php echo e($mp-> deskripsi_produk); ?></td>
                                            <td><?php echo e($mp-> keduluarsa); ?></td>
                                            <td><?php echo e($mp-> stok); ?></td>
                                            <td>
                                                    <a href="" class="badge badge-succes">Edit</a>
                                                    <a href="" class="badge badge-denger">Delete</a>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OurProject\resources\views/page/admin/mproduk.blade.php ENDPATH**/ ?>