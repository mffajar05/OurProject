<?php $__env->startSection('title','Kantinkita'); ?>

<?php $__env->startSection('content'); ?>
      <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Penjualan</h1>
                    <p class="mb-4"> Statistik Penjualan KantinKita.id</p>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th scope="row"> # </th>
                                            <th>Produk</th>
                                            <th>Kode Produk</th>
                                            <th>Tanggal Transaksi</th>
                                            <th>Invoice</th>
                                            <th>Kasir</th>
                                            <th>Status</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pjl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scoop="row"><?php echo e($loop->iteration); ?></th>
                                            <td><?php echo e($pjl->nama_produk); ?></td>
                                            <td><?php echo e($pjl->kode_produk); ?></td>
                                            <td><?php echo e($pjl->tanggal_transaksi); ?></td>
                                            <td><?php echo e($pjl->invoice); ?></td>
                                            <td><?php echo e($pjl->kasir); ?></td>
                                            <td><?php echo e($pjl->transaction_status); ?></td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OurProject\resources\views/page/admin/penjualan.blade.php ENDPATH**/ ?>