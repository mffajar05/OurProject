<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Document</title>
</head>
<body>
    <br>
    <h2 class="ml-3">Data Dosen</h2>
    <br>

    <div class="card" align="center" >
        <div class="card-body">
          <h5 class="card-title"><?php echo e($dosen->nama_lengkap); ?></h5>
          <hr>
          <h6 class="card-subtitle mb-2 text-muted"><?php echo e($dosen->nidn); ?></h6>
          <hr>
          <p class="card-text"><?php echo e($dosen->tempat_lahir); ?>,<?php echo e($dosen->tanggal_lahir); ?></p>
          <hr>
          <h6 class="card-subtitle mb-2 text-muted"><?php echo e($dosen->jenis_kelamin); ?></h6>
          <hr>
          <p class="card-text"><?php echo e($dosen->alamat); ?></p>
          <hr>
          <h6 class="card-subtitle mb-2 text-muted"><?php echo e($dosen->program_studi); ?></h6>
          <hr>
          <a href="<?php echo e($dosen->id); ?>/edit" class="btn btn-primary"> Edit</a>

          <form action="/dosens/<?php echo e($dosen->id); ?>" method="post">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-danger"> Delete</button>
        </form>
          <div>

              <br>
            <a href="/dosens" class="card-link ">kembali</a>
          </div>

        </div>
      </div>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\OurProject\resources\views/dosen_detail.blade.php ENDPATH**/ ?>