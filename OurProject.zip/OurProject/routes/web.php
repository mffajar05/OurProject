<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/', 'PageController@dashboard');
Route::get('/konfirmasi-pesanan', 'PageController@konfirmasi');
Route::get('/penjualan', 'PageController@penjualan');

Route::get('/tambah', 'PageController@tambah');


// Route::get('/dosens', 'DosensController@index'); //tampilin view
// Route::get('/dosens/tambah', 'DosensController@create'); // ke halaman tambah
// Route::get('/dosens/{dosen}', 'DosensController@show'); //detail
// Route::post('/dosens', 'DosensController@store'); //tambah
// Route::delete('/dosens/{dosen}', 'DosensController@destroy'); //hapus
// Route::get('/dosens/{dosen}/edit', 'DosensController@edit'); //edit
// Route::patch('/dosens/{dosen}', 'DosensController@update'); //tangkap perubahan edit


// Route::get('/databases', 'DatabasesController@index'); //tampilin view



// //Route::get('/tambahdata', 'DosenController@tambahdata');
// //Route::get('/dosen_detail/{dosen_detail}', 'DosenController@show');
// //Route::get('/collect', 'CollectionController@collectionMahasiswa');
