<?php
$arrMahasiswa = ["Risa Lestari","Rudi Hermawan","Bambang Kusumo",
"Lisa Permata"];

        foreach($arrMahasiswa as $mhs)
        {
            echo $mhs."\n";
        }

?>