<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    @include('include.style')
    <title>Document</title>
</head>
<body>
    <h2>Form Ubah Data Dosen</h2>
   <form class=" col-7 heigh" method="post" action="/dosens/{{ $dosen->id}}">
    @method('patch')
    @csrf

    <div class="form-group">
        <label for="nama_lengkap">NAMA</label>
        <input type="text" class="form-control" placeholder="Masukan Nama" id="nama_lengkap" name="nama_lengkap" value="{{ $dosen->nama_lengkap}}">
      </div>
      <div class="form-group">
        <label for="nidn">NIDN</label>
        <input type="text" class="form-control" placeholder="Nomor Induk Dosen Nasional" id="nidn" name="nidn" value="{{ $dosen->nidn}}">
      </div>
      <div class="form-group">
        <label for="tempat_lahir">Tempat lahir</label>
        <input type="text" class="form-control" placeholder="Tempat Lahir" id="tempat_lahir" name="tempat_lahir" value="{{ $dosen->tempat_lahir}}">
      </div>
      <div class="form-group">
        <label for="tanggal_lahir">Tanggal lahir</label>
        <input type="text" class="form-control" placeholder="yyyy-mm-dd" id="tanggal_lahir" name="tanggal_lahir" value="{{ $dosen->tanggal_lahir}}">
      </div>
      <div class="form-group">
        <label for="jenis_kelamin">Jenis kelamin</label>
        <input type="text" class="form-control" placeholder="Jenis Kelamin" id="jenis_kelamin" name="jenis_kelamin" value="{{ $dosen->jenis_kelamin}}">
      </div>
      <div class="form-group">
        <label for="alamat">Alamat</label>
        <input type="text" class="form-control" placeholder="Alamat" id="alamat" name="alamat" value="{{ $dosen->alamat}}">
      </div>
      <div class="form-group">
        <label for="program_studi">Program Studi</label>
        <input type="text" class="form-control" placeholder="Program Studi" id="program_studi" name="program_studi" value="{{ $dosen->program_studi}}">
      </div>
      <button type="submit" class="btn btn-primary">Ubah Data</button>
   </form>


</body>
</html>
