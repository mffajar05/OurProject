@extends('layout.admin')
@section('title','Kantinkita')

@section('content')
      <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Penjualan</h1>
                    <p class="mb-4"> Statistik Penjualan KantinKita.id</p>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th scope="row"> # </th>
                                            <th>Produk</th>
                                            <th>Kode Produk</th>
                                            <th>Tanggal Transaksi</th>
                                            <th>Invoice</th>
                                            <th>Kasir</th>
                                            <th>Status</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                    @foreach( $penjualan as $pjl)
                                        <tr>
                                            <th scoop="row">{{ $loop->iteration}}</th>
                                            <td>{{ $pjl->nama_produk}}</td>
                                            <td>{{ $pjl->kode_produk}}</td>
                                            <td>{{ $pjl->tanggal_transaksi}}</td>
                                            <td>{{ $pjl->invoice}}</td>
                                            <td>{{ $pjl->kasir}}</td>
                                            <td>{{ $pjl->transaction_status}}</td>

                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->




@endsection
