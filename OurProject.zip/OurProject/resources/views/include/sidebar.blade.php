<!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ url('/')}}">

                <div class="sidebar-brand-text mx-3">Kantinkita.id</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="{{ url('/')}}">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

                <!-- Nav Item - konfirmasi pesanan -->
            <li class="nav-item active">
                <a class="nav-link" href="{{ url('/konfirmasi-pesanan')}}">
                    <i class="fas fa-fw fa-check"></i>
                    <span>Konfirmasi Pesanan</span></a>
            </li>
             <!-- Nav Item - penjualan-->
            <li class="nav-item active">
                <a class="nav-link" href="{{ url('/penjualan')}}">
                    <i class="fas fa-fw fa-book"></i>
                    <span>Penjualan</span></a>
            </li>
             <!-- Nav Item - Manajemen Produk -->
            <li class="nav-item active">
                <a class="nav-link" href="{{ url('/manajemen-produk')}}">
                    <i class="fas fa-fw fa-tasks"></i>
                    <span>Manajemen Produk</span>
                </a>
                <div class="">
                    <a class="nav-link" href="{{ url('/tambah')}}">
                        <i class="fas fa-fw "></i>
                        <span>Tambah Produk</span>
                    </a>
                </div>
            </li>









            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>


        </ul>
        <!-- End of Sidebar -->
