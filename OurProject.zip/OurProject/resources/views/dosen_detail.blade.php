<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    @include('include.style')
    <title>Document</title>
</head>
<body>
    <br>
    <h2 class="ml-3">Data Dosen</h2>
    <br>

    <div class="card" align="center" >
        <div class="card-body">
          <h5 class="card-title">{{ $dosen->nama_lengkap}}</h5>
          <hr>
          <h6 class="card-subtitle mb-2 text-muted">{{ $dosen->nidn}}</h6>
          <hr>
          <p class="card-text">{{ $dosen->tempat_lahir}},{{ $dosen->tanggal_lahir}}</p>
          <hr>
          <h6 class="card-subtitle mb-2 text-muted">{{ $dosen->jenis_kelamin}}</h6>
          <hr>
          <p class="card-text">{{ $dosen->alamat}}</p>
          <hr>
          <h6 class="card-subtitle mb-2 text-muted">{{ $dosen->program_studi}}</h6>
          <hr>
          <a href="{{ $dosen->id}}/edit" class="btn btn-primary"> Edit</a>

          <form action="/dosens/{{$dosen->id}}" method="post">
            @method('delete')
            @csrf
          <button type="submit" class="btn btn-danger"> Delete</button>
        </form>
          <div>

              <br>
            <a href="/dosens" class="card-link ">kembali</a>
          </div>

        </div>
      </div>


</body>
</html>
