<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    @include('include.style')
    <title>Document</title>
</head>
<body>
     <!-- Begin Page Content -->
     <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Data Dosen Universitas Borneo </h1>
        <p class="mb-4"> Tahun Ajaran 2021-2022</p>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class=" btn btn-primary"><a href="{{ url('/dosens/tambah')}}"">Tambah Data</a></h6>

                @if (session('status'))
                <div class="alert alert-succes">
                    {{session('status')}}

                </div>

                @endif
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th scope="row"> No </th>
                                <th>NIDN</th>
                                <th>Nama Lengkap</th>
                                <th>Tempat Lahir</th>
                                <th>Tanggal Lahir</th>
                                <th>Jenis Kelamin</th>
                                <th>Alamat</th>
                                <th>Program Studi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach( $dosen as $dsn)
                            <tr>
                                <th scoop="row">{{ $loop->iteration}}</th>
                                <td>{{ $dsn->nidn}}</td>
                                <td>{{ $dsn->nama_lengkap}}</td>
                                <td>{{ $dsn->tempat_lahir}}</td>
                                <td>{{ $dsn->tanggal_lahir}}</td>
                                <td>{{ $dsn->jenis_kelamin}}</td>
                                <td>{{ $dsn->alamat}}</td>
                                <td>{{ $dsn->program_studi}}</td>
                                <td>
                                    <a href="/dosens/{{$dsn->id}}" class="badge badge-succes">Detail</a>
                            </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->


</body>
</html>
